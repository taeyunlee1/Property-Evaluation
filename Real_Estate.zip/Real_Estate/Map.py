import requests
import folium
import pandas as pd
import os


# url = 'http://api.vworld.kr/req/address?'
# params = 'service=address&request=getcoord&version=2.0&crs=epsg:4326&refine=true&simple=false&format=json&type='
# road_type = 'ROAD' #도로명 주소
# road_type2 = 'PARCEL' #지번 주소
# address = '&address='
# keys = '&key='
# primary_key = 'B6B30F8F-B61E-3BBE-889D-A0A9638F7CB9'

# def request_geo(road):
#     page = requests.get(url+params+road_type+address+road+keys+primary_key)
#     json_data = page.json()
#     if json_data['response']['status'] == 'OK':
#         x = json_data['response']['result']['point']['x']
#         y = json_data['response']['result']['point']['y']
#         return y, x
#     else:
#         x = 0
#         y = 0
#         return y, x
    
# def request_geo2(parcel):
#     page = requests.get(url+params+road_type2+address+parcel+keys+primary_key)
#     json_data = page.json()
#     if json_data['response']['status'] == 'OK':
#         x = json_data['response']['result']['point']['x']
#         y = json_data['response']['result']['point']['y']
#         return y, x
#     else:
#         x = 0
#         y = 0
#         return y, x

# # x,y = request_geo("경기도 시흥시 산기대학로 237 (정왕동, 한국산업기술대학교)"

# # x, y = request_geo2('관양동 1588-8')

print("hi")

df = pd.read_csv('center.csv')

# search_value = input("Please enter the address: ")

# #new column with 3 + 6 column
# df['concatenated'] = df.iloc[:, 2].astype(str) + " " + df.iloc[:, 5].astype(str)
# result = df[df['concatenated'] == search_value]

# if not result.empty:
#     print(f"{search_value} not found ")
# else:
#     x, y = request_geo2(result)

# def viz_map(x, y):
#     # Create a map centered at the given coordinates
#     m = folium.Map(
#         location=[x, y],
#         zoom_start=17,
#         width=800,
#         height=400,
#     )
#     # Add a marker to the map
#     folium.Marker([x, y], popup='관악역', tooltip='관악역 위치').add_to(m)
#     return m

# # Create the map
# map_ = viz_map(x, y)

# # Display the map directly in the Jupyter Notebook
# map_