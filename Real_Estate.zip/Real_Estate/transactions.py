import requests
import xmltodict
import pandas as pd
import json
from datetime import datetime

def get_lawd_cd(address):
    url = "http://apis.data.go.kr/1741000/StanReginCd/getStanReginCdList"
    key = "qYw0R6C6Bg%2B5ri%2FHos1QJKjONiWb60o9lKPBSSE95Q9FsTay8WkAdqYV90kxPy3FoCGvmFUEo2%2F4zktiepPlYA%3D%3D"
    params = {
        "serviceKey": key,
        "pageNo": "1",
        "numOfRows": "3",
        "type": "json",
        "locatadd_nm": address
    }
    r = requests.get(url, params=params)
    _json = r.json()
    results = _json.get("StanReginCd")
    if len(results) > 0:
        return results[1].get("row", [])[0].get("region_cd")[0:5]
    return None

LAWD_CD = get_lawd_cd("경기도 과천시")
DEAL_YMD = "202210"
key = "인증받은 decoding api키값"
url = "http://openapi.molit.go.kr:8081/OpenAPI_ToolInstallPackage/service/rest/RTMSOBJSvc/getRTMSDataSvcAptTrade"
params = {
    "serviceKey": key,
    "LAWD_CD": LAWD_CD,
    "DEAL_YMD": DEAL_YMD
}

req = requests.get(url, params=params)
result = xmltodict.parse(req.text)
items = result.get("response").get("body").get("items").get("item")

jsonString = json.dumps(items)  # list를 json방식으로 업데이트
df = pd.DataFrame(items)
display(df)
